package com.proiectipdp.chess;

import javafx.stage.Stage;
import org.junit.jupiter.api.Test;
import org.testfx.framework.junit5.ApplicationTest;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.base.NodeMatchers.isVisible;

/*
    Test automat pentru MainApp.

    Verifica:
    1. daca MainApp porneste corect aplicatia;
    2. daca titlul ferestrei este cel asteptat;
    3. daca aplicatia porneste cu StartView;
    4. daca metoda formatTime formateaza corect timpul folosit de ceasurile din joc.
*/

public class MainAppTest extends ApplicationTest {

    private Stage stage;
    private MainApp app;

    @Override
    public void start(Stage stage) {
        this.stage = stage;
        this.app = new MainApp();
        this.app.start(stage);
    }

    @Test
    void testMainAppPornesteCuStartView() {
        assertEquals("Proiect Sah IPDP", stage.getTitle());
        assertFalse(stage.isResizable(), "Fereastra este setata ca neredimensionabila in MainApp.");

        verifyThat("Chess Game", isVisible());
        verifyThat("Joacă!", isVisible());
        verifyThat("Logare", isVisible());
    }

    @Test
    void testFormatTimePentruCeasuri() throws Exception {
        Method formatTime = MainApp.class.getDeclaredMethod("formatTime", int.class);
        formatTime.setAccessible(true);

        assertEquals("10:00", formatTime.invoke(app, 600));
        assertEquals("05:00", formatTime.invoke(app, 300));
        assertEquals("00:59", formatTime.invoke(app, 59));
        assertEquals("00:00", formatTime.invoke(app, 0));
        assertEquals("00:00", formatTime.invoke(app, -5));
    }
}
