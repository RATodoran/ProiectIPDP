package com.proiectipdp.chess;

import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import org.junit.jupiter.api.Test;
import org.testfx.framework.junit5.ApplicationTest;

import java.lang.reflect.Field;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.base.NodeMatchers.isVisible;

/*
    Test automat pentru GameSettingsView.

    Verifica:
    1. daca ecranul de setari se incarca;
    2. daca valorile default sunt corecte:
       - timp: 10 minute
       - culoare: Alb / WHITE
       - allowIllegalMoves: false
    3. daca selectarea altor optiuni modifica atat interfata, cat si campurile interne.
*/

public class GameSettingsViewTest extends ApplicationTest {

    private GameSettingsView view;

    @Override
    public void start(Stage stage) {
        view = new GameSettingsView(new MainApp());
        stage.setScene(view.getScene());
        stage.show();
    }

    @Test
    void testGameSettingsViewAfiseazaElementelePrincipale() {
        verifyThat("Game Settings", isVisible());
        verifyThat("Timp de joc", isVisible());
        verifyThat("Culoare", isVisible());
        verifyThat("Allow illegal moves", isVisible());
        verifyThat("Start Game", isVisible());
    }

    @Test
    void testValorileDefaultSuntCorecte() throws Exception {
        RadioButton zeceMinute = getRadioButtonByText("10 min");
        RadioButton alb = getRadioButtonByText("Alb");
        CheckBox allowIllegal = getCheckBoxByText("Allow illegal moves");

        assertTrue(zeceMinute.isSelected(), "Default trebuie sa fie selectat timpul de 10 minute.");
        assertTrue(alb.isSelected(), "Default trebuie sa fie selectata culoarea Alb.");
        assertFalse(allowIllegal.isSelected(), "Default mutarile ilegale trebuie sa fie dezactivate.");

        assertEquals(10, getPrivateField("selectedTime"));
        assertEquals("WHITE", getPrivateField("selectedColor"));
        assertEquals(false, getPrivateField("allowIllegalMoves"));
    }

    @Test
    void testSelectareaTimpuluiDe30Minute() throws Exception {
        clickOn("30 min");

        RadioButton treizeciMinute = getRadioButtonByText("30 min");

        assertTrue(treizeciMinute.isSelected(), "Dupa click, trebuie selectat timpul de 30 minute.");
        assertEquals(30, getPrivateField("selectedTime"));
    }

    @Test
    void testSelectareaCuloriiNegre() throws Exception {
        clickOn("Negru");

        RadioButton negru = getRadioButtonByText("Negru");

        assertTrue(negru.isSelected(), "Dupa click, trebuie selectata culoarea Negru.");
        assertEquals("BLACK", getPrivateField("selectedColor"));
    }

    @Test
    void testSelectareaCuloriiRandom() throws Exception {
        clickOn("Random");

        RadioButton random = getRadioButtonByText("Random");

        assertTrue(random.isSelected(), "Dupa click, trebuie selectata optiunea Random.");
        assertEquals("RANDOM", getPrivateField("selectedColor"));
    }

    @Test
    void testActivareAllowIllegalMoves() throws Exception {
        clickOn("Allow illegal moves");

        CheckBox allowIllegal = getCheckBoxByText("Allow illegal moves");

        assertTrue(allowIllegal.isSelected(), "Dupa click, checkbox-ul trebuie sa fie bifat.");
        assertEquals(true, getPrivateField("allowIllegalMoves"));
    }

    private RadioButton getRadioButtonByText(String text) {
        Set<RadioButton> radioButtons = lookup(".radio-button").queryAllAs(RadioButton.class);

        return radioButtons.stream()
                .filter(radioButton -> text.equals(radioButton.getText()))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Nu am gasit RadioButton cu textul: " + text));
    }

    private CheckBox getCheckBoxByText(String text) {
        Set<CheckBox> checkBoxes = lookup(".check-box").queryAllAs(CheckBox.class);

        return checkBoxes.stream()
                .filter(checkBox -> text.equals(checkBox.getText()))
                .findFirst()
                .orElseThrow(() -> new AssertionError("Nu am gasit CheckBox cu textul: " + text));
    }

    private Object getPrivateField(String fieldName) throws Exception {
        Field field = GameSettingsView.class.getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(view);
    }
}
