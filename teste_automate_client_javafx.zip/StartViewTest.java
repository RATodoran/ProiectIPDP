package com.proiectipdp.chess;

import javafx.stage.Stage;
import org.junit.jupiter.api.Test;
import org.testfx.framework.junit5.ApplicationTest;

import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.base.NodeMatchers.isVisible;

/*
    Test automat pentru StartView.

    Verifica:
    1. daca aplicatia porneste cu ecranul principal;
    2. daca exista butoanele "Joacă!" si "Logare";
    3. daca apasarea butonului "Joacă!" deschide ecranul GameSettingsView.
*/

public class StartViewTest extends ApplicationTest {

    @Override
    public void start(Stage stage) {
        MainApp app = new MainApp();
        app.start(stage);
    }

    @Test
    void testStartViewAfiseazaElementelePrincipale() {
        verifyThat("Chess Game", isVisible());
        verifyThat("Pregătește partida și intră pe tablă", isVisible());
        verifyThat("Joacă!", isVisible());
        verifyThat("Logare", isVisible());
    }

    @Test
    void testButonJoacaDeschideGameSettingsView() {
        clickOn("Joacă!");

        verifyThat("Game Settings", isVisible());
        verifyThat("Timp de joc", isVisible());
        verifyThat("Culoare", isVisible());
        verifyThat("Start Game", isVisible());
    }
}
